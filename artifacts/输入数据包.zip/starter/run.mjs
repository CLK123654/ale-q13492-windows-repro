import path from "node:path";

const [, , inputArgument, outputArgument] = process.argv;
if (!inputArgument || !outputArgument) {
  throw new Error("usage: node run.mjs input_dir output_dir");
}

throw new Error(
  `TODO: recover ${path.resolve(inputArgument)} with sqlite3 and write ${path.resolve(outputArgument)}`,
);
