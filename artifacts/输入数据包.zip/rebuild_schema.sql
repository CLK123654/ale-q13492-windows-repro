PRAGMA foreign_keys=ON;
CREATE TABLE categories(
  category_id INTEGER PRIMARY KEY,
  category_name TEXT NOT NULL UNIQUE
);
CREATE TABLE catalog_entries(
  entry_id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE CHECK(code GLOB 'CAT-*'),
  label TEXT NOT NULL,
  scope TEXT NOT NULL CHECK(scope IN('internal','public','restricted')),
  category_id INTEGER NOT NULL REFERENCES categories(category_id),
  enabled INTEGER NOT NULL CHECK(enabled IN(0,1))
);
CREATE INDEX catalog_entries_category_scope_idx
ON catalog_entries(category_id,scope,entry_id);
CREATE TABLE audit_notes(
  note_id INTEGER PRIMARY KEY,
  event_key TEXT NOT NULL,
  detail TEXT NOT NULL
);
CREATE TABLE recovery_meta(
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  recovered_catalog_rows INTEGER NOT NULL,
  rejected_retired_rows INTEGER NOT NULL,
  raw_fragment_rows INTEGER NOT NULL,
  source_user_version INTEGER NOT NULL,
  source_application_id INTEGER NOT NULL,
  recovery_status TEXT NOT NULL CHECK(recovery_status='PASS')
);
