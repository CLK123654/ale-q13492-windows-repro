BEGIN;
PRAGMA writable_schema = on;
PRAGMA encoding = 'UTF-8';
PRAGMA page_size = '1024';
PRAGMA auto_vacuum = '0';
PRAGMA user_version = '27';
PRAGMA application_id = '1095517493';
CREATE TABLE categories(
  category_id INTEGER PRIMARY KEY,
  category_name TEXT NOT NULL UNIQUE
);
CREATE TABLE audit_notes(
  note_id INTEGER PRIMARY KEY,
  event_key TEXT NOT NULL,
  detail TEXT NOT NULL
);
INSERT OR IGNORE INTO 'categories'('category_id', 'category_name') VALUES (10, 'commercial');
INSERT OR IGNORE INTO 'categories'('category_id', 'category_name') VALUES (20, 'security');
INSERT OR IGNORE INTO 'categories'('category_id', 'category_name') VALUES (30, 'operations');
INSERT OR IGNORE INTO 'audit_notes'('note_id', 'event_key', 'detail') VALUES (1, 'migration-start', 'catalog snapshot accepted');
INSERT OR IGNORE INTO 'audit_notes'('note_id', 'event_key', 'detail') VALUES (2, 'schema-loss', 'catalog and cache definitions missing');
CREATE TABLE recovered_fragments(rootpgno INTEGER, pgno INTEGER, nfield INTEGER, id INTEGER, c0, c1, c2, c3, c4, c5);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1001, NULL, 'CAT-ALPHA', 'Starter Plan', 'public', 10, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1002, NULL, 'CAT-BETA', 'Growth Plan', 'public', 10, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1003, NULL, 'CAT-GAMMA', 'Audit Export', 'internal', 20, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1004, NULL, 'CAT-DELTA', 'Retention Window', 'internal', 20, 0);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1005, NULL, 'CAT-EPSILON', 'Invoice Sync', 'public', 30, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1006, NULL, 'CAT-ZETA', 'Team Seats', 'public', 10, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1007, NULL, 'CAT-ETA', 'Token Vault', 'restricted', 20, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1008, NULL, 'CAT-THETA', 'Usage Meter', 'public', 30, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1009, NULL, 'CAT-IOTA', 'Webhook Retry', 'internal', 30, 0);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1010, NULL, 'CAT-KAPPA', 'Sandbox Key', 'restricted', 20, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1011, NULL, 'CAT-LAMBDA', 'Data Region', 'public', 30, 1);
INSERT INTO recovered_fragments VALUES(4, 4, 6, 1012, NULL, 'CAT-MU', 'Rate Limit', 'internal', 10, 1);
INSERT INTO recovered_fragments VALUES(5, 5, 6, 8101, NULL, 'OLD-PRICE', 'v1-price', 'expired', 10, 0);
INSERT INTO recovered_fragments VALUES(5, 5, 6, 8102, NULL, 'OLD-TOKEN', 'v1-token', 'revoked', 20, 0);
INSERT INTO recovered_fragments VALUES(5, 5, 6, 8103, NULL, 'OLD-ROUTE', 'v1-route', 'replaced', 30, 0);
PRAGMA writable_schema = off;
COMMIT;
