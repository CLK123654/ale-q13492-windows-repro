import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";

function fail(message) {
  throw new Error(message);
}

function runSqlite(executable, args, input = "") {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, args, { windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) reject(new Error(stderr.trim() || `sqlite3 exited ${code}`));
      else resolve({ stdout, stderr });
    });
    child.stdin.end(input);
  });
}

function sqlLiteral(value) {
  if (value === null || value === undefined) return "NULL";
  if (typeof value === "number") {
    if (!Number.isFinite(value)) fail("non-finite SQL number");
    return String(value);
  }
  return `'${String(value).replaceAll("'", "''")}'`;
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replaceAll("\"", "\"\"")}"` : text;
}

function toCsv(rows, columns) {
  return `${[
    columns,
    ...rows.map((row) => columns.map((column) => row[column])),
  ]
    .map((row) => row.map(csvCell).join(","))
    .join("\n")}\n`;
}

async function snapshot(root) {
  const result = new Map();
  async function visit(directory) {
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      const target = path.join(directory, entry.name);
      if (entry.isDirectory()) await visit(target);
      else if (entry.isFile()) {
        result.set(
          path.relative(root, target).split(path.sep).join("/"),
          await fs.readFile(target),
        );
      }
    }
  }
  await visit(root);
  return result;
}

function sameSnapshot(left, right) {
  if (left.size !== right.size) return false;
  for (const [name, data] of left) {
    if (!right.get(name)?.equals(data)) return false;
  }
  return true;
}

async function queryJson(sqlite, database, sql) {
  const { stdout } = await runSqlite(sqlite, ["-json", database, sql]);
  return stdout.trim() ? JSON.parse(stdout) : [];
}

function validateRules(rules) {
  if (rules.lost_and_found_table !== "recovered_fragments") {
    fail("lost_and_found_table must be recovered_fragments");
  }
  if (
    rules.catalog_prefix !== "CAT-" ||
    rules.retired_prefix !== "OLD-" ||
    rules.expected_catalog_rows !== 12 ||
    rules.expected_retired_rows !== 3
  ) {
    fail("recovery row contract is invalid");
  }
  if (
    JSON.stringify(rules.expected_categories) !== JSON.stringify([10, 20, 30]) ||
    new Set(rules.allowed_scopes).size !== 3
  ) {
    fail("category or scope contract is invalid");
  }
}

async function main() {
  const [, , inputArgument, outputArgument] = process.argv;
  if (!inputArgument || !outputArgument) {
    fail("usage: node run.mjs input_dir output_dir");
  }
  const inputDir = await fs.realpath(path.resolve(inputArgument));
  const outputDir = path.resolve(outputArgument);
  const damagedDatabase = path.join(inputDir, "damaged_catalog.db");
  const rules = JSON.parse(
    await fs.readFile(path.join(inputDir, "recovery_rules.json"), "utf8"),
  );
  const rebuildSchema = await fs.readFile(
    path.join(inputDir, "rebuild_schema.sql"),
    "utf8",
  );
  validateRules(rules);
  const before = await snapshot(inputDir);
  const sqlite =
    process.env.SQLITE3_EXECUTABLE ||
    (process.platform === "win32" ? "sqlite3.exe" : "sqlite3");
  const version = (await runSqlite(sqlite, ["--version"])).stdout.trim();
  const versionNumber = version.split(/\s+/)[0];
  const workDir = path.join(
    path.dirname(outputDir),
    `.${path.basename(outputDir)}.sqlite-recover-work`,
  );
  const rawDatabase = path.join(workDir, "raw_recovered.db");
  const cleanDatabase = path.join(workDir, "catalog_rebuilt.db");
  await fs.rm(workDir, { recursive: true, force: true });
  await fs.mkdir(workDir, { recursive: true });
  try {
    const sourceMetaRows = await queryJson(
      sqlite,
      damagedDatabase,
      "SELECT (SELECT user_version FROM pragma_user_version) AS user_version,(SELECT application_id FROM pragma_application_id) AS application_id;",
    );
    const sourceMeta = sourceMetaRows[0];
    if (
      sourceMeta.user_version !== rules.required_user_version ||
      sourceMeta.application_id !== rules.required_application_id
    ) {
      fail("database identity does not match recovery rules");
    }
    const damagedIntegrity = await queryJson(
      sqlite,
      damagedDatabase,
      "PRAGMA integrity_check;",
    );
    if (damagedIntegrity.length < 1 || damagedIntegrity.every((row) => row.integrity_check === "ok")) {
      fail("source database does not expose orphan-page damage");
    }

    const recoveryCommand = `.recover --lost-and-found ${rules.lost_and_found_table}\n`;
    const recoverySql = (await runSqlite(sqlite, [damagedDatabase], recoveryCommand))
      .stdout;
    if (!recoverySql.includes(`CREATE TABLE ${rules.lost_and_found_table}`)) {
      fail("sqlite3 recover did not emit the fragment table");
    }
    await fs.writeFile(path.join(workDir, "recovery.sql"), recoverySql, "utf8");
    await runSqlite(sqlite, [rawDatabase], recoverySql);

    const fragments = await queryJson(
      sqlite,
      rawDatabase,
      `SELECT rootpgno,pgno,nfield,id,c1 AS code,c2 AS label,c3 AS scope,c4 AS category_id,c5 AS enabled
       FROM ${rules.lost_and_found_table}
       ORDER BY rootpgno,id;`,
    );
    const catalog = fragments.filter((row) =>
      String(row.code ?? "").startsWith(rules.catalog_prefix),
    );
    const retired = fragments.filter((row) =>
      String(row.code ?? "").startsWith(rules.retired_prefix),
    );
    if (
      fragments.length !== rules.expected_catalog_rows + rules.expected_retired_rows ||
      catalog.length !== rules.expected_catalog_rows ||
      retired.length !== rules.expected_retired_rows
    ) {
      fail("recovered fragment counts do not match the contract");
    }
    if (
      catalog.some(
        (row) =>
          row.nfield !== 6 ||
          !rules.allowed_scopes.includes(row.scope) ||
          !rules.expected_categories.includes(row.category_id) ||
          ![0, 1].includes(row.enabled),
      )
    ) {
      fail("catalog fragment shape or value is invalid");
    }

    const categories = await queryJson(
      sqlite,
      rawDatabase,
      "SELECT category_id,category_name FROM categories ORDER BY category_id;",
    );
    const auditNotes = await queryJson(
      sqlite,
      rawDatabase,
      "SELECT note_id,event_key,detail FROM audit_notes ORDER BY note_id;",
    );
    if (
      JSON.stringify(categories.map((row) => row.category_id)) !==
      JSON.stringify(rules.expected_categories)
    ) {
      fail("recovered categories do not match the contract");
    }

    const buildSql = [
      "PRAGMA foreign_keys=ON;",
      "BEGIN;",
      rebuildSchema,
      ...categories.map(
        (row) =>
          `INSERT INTO categories VALUES(${sqlLiteral(row.category_id)},${sqlLiteral(row.category_name)});`,
      ),
      ...catalog.map(
        (row) =>
          `INSERT INTO catalog_entries VALUES(${[
            row.id,
            row.code,
            row.label,
            row.scope,
            row.category_id,
            row.enabled,
          ]
            .map(sqlLiteral)
            .join(",")});`,
      ),
      ...auditNotes.map(
        (row) =>
          `INSERT INTO audit_notes VALUES(${[
            row.note_id,
            row.event_key,
            row.detail,
          ]
            .map(sqlLiteral)
            .join(",")});`,
      ),
      `INSERT INTO recovery_meta VALUES(1,${catalog.length},${retired.length},${fragments.length},${sourceMeta.user_version},${sourceMeta.application_id},'PASS');`,
      `PRAGMA user_version=${sourceMeta.user_version};`,
      `PRAGMA application_id=${sourceMeta.application_id};`,
      "COMMIT;",
    ].join("\n");
    await runSqlite(sqlite, [cleanDatabase], buildSql);

    const integrity = await queryJson(sqlite, cleanDatabase, "PRAGMA integrity_check;");
    const foreignKeys = await queryJson(sqlite, cleanDatabase, "PRAGMA foreign_key_check;");
    if (
      integrity.length !== 1 ||
      integrity[0].integrity_check !== "ok" ||
      foreignKeys.length !== 0
    ) {
      fail("rebuilt database integrity check failed");
    }
    const catalogRows = await queryJson(
      sqlite,
      cleanDatabase,
      `SELECT entry_id,code,label,scope,category_id,enabled
       FROM catalog_entries ORDER BY entry_id;`,
    );
    const planText = (
      await runSqlite(sqlite, [
        cleanDatabase,
        "EXPLAIN QUERY PLAN SELECT entry_id FROM catalog_entries WHERE category_id=20 AND scope='restricted' ORDER BY entry_id;",
      ])
    ).stdout;
    const indexUsed = planText.includes("catalog_entries_category_scope_idx");
    if (catalogRows.length !== 12 || !indexUsed) fail("rebuilt catalog or index is invalid");

    const inventory = fragments.map((row) => ({
      rootpgno: row.rootpgno,
      pgno: row.pgno,
      nfield: row.nfield,
      row_id: row.id,
      code: row.code,
      disposition: String(row.code).startsWith(rules.catalog_prefix)
        ? "restored_catalog"
        : "rejected_retired_cache",
    }));
    await fs.writeFile(
      path.join(workDir, "recovered_catalog.csv"),
      toCsv(catalogRows, [
        "entry_id",
        "code",
        "label",
        "scope",
        "category_id",
        "enabled",
      ]),
      "utf8",
    );
    await fs.writeFile(
      path.join(workDir, "fragment_inventory.csv"),
      toCsv(inventory, [
        "rootpgno",
        "pgno",
        "nfield",
        "row_id",
        "code",
        "disposition",
      ]),
      "utf8",
    );
    const report = {
      status: "PASS",
      sqlite_version: versionNumber,
      recover_command: `.recover --lost-and-found ${rules.lost_and_found_table}`,
      source_user_version: sourceMeta.user_version,
      source_application_id: sourceMeta.application_id,
      damaged_integrity_issue_count: damagedIntegrity.length,
      raw_fragment_rows: fragments.length,
      recovered_catalog_rows: catalog.length,
      rejected_retired_rows: retired.length,
      recovered_category_rows: categories.length,
      recovered_audit_rows: auditNotes.length,
      rebuilt_integrity_check: "ok",
      foreign_key_violation_count: foreignKeys.length,
      category_scope_index_used: indexUsed,
      input_unchanged: sameSnapshot(before, await snapshot(inputDir)),
    };
    if (!report.input_unchanged) fail("input directory changed during recovery");
    await fs.writeFile(
      path.join(workDir, "recovery_report.json"),
      `${JSON.stringify(report, null, 2)}\n`,
      "utf8",
    );
    await fs.copyFile(new URL(import.meta.url), path.join(workDir, "run.mjs"));
    await fs.rm(rawDatabase, { force: true });
    await fs.rm(outputDir, { recursive: true, force: true });
    await fs.rename(workDir, outputDir);
  } catch (error) {
    await fs.rm(workDir, { recursive: true, force: true });
    throw error;
  }
}

try {
  await main();
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
